#include "qform1.h"
#include "ui_qform1.h"


QMap<QString, QString> ipToCarMap; // Relación IP -> Auto
QSet<QString> availableCars;      // Autos disponibles
QMap<QString, QJsonObject> globalCarStates;   //Estados globales de Race Four
QMap<QString, QJsonObject> globalSnakeStates; // Estados del juego Snake por IP
QMap<QString, QJsonArray> globalScores;  // Mapa global para almacenar puntajes por cliente




Qform1::Qform1(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Qform1)
    , server(new QTcpServer(this))
{
    ui->setupUi(this);

    // Autos disponibles
    availableCars = {"a", "b", "c", "d"};

    globalCarStates = {
        {"a", QJsonObject{{"x", 740}, {"y", 135}, {"angulo", 0.0}}},
        {"b", QJsonObject{{"x", 740}, {"y", 95}, {"angulo", 0.0}}},
        {"c", QJsonObject{{"x", 740}, {"y", 55}, {"angulo", 0.0}}},
        {"d", QJsonObject{{"x", 740}, {"y", 15}, {"angulo", 0.0}}}
    };
    // Configurar el servidor
    connect(ui->boton_iniciar, &QPushButton::clicked, this, &Qform1::startServer);
    connect(server, &QTcpServer::newConnection, this, &Qform1::handleNewConnection);

}


Qform1::~Qform1()
{
    delete ui;
}




void Qform1::startServer() {
    if (serverRunning) {
        // Si el servidor está corriendo, detenerlo y limpiar el depurador
        for (QTcpSocket *socket : clientSockets) {
            socket->disconnectFromHost();
        }
        clientSockets.clear(); // Limpiar lista de clientes
        server->close();
        ui->depurador->clear();
        ui->depurador->append("Servidor detenido.");

        // Liberar todos los recursos
        ipToCarMap.clear();
        availableCars = {"a", "b", "c", "d"};
        connectedIps.clear();

        // Cambiar el texto del botón
        ui->boton_iniciar->setText("Iniciar");

        serverRunning = false;
    } else {
        if (server->listen(QHostAddress::Any, 8080)) {
            ui->depurador->append("Servidor iniciado en el puerto 8080.");
            // Cambiar el texto del botón
            ui->boton_iniciar->setText("Detener");

            serverRunning = true;
        } else {
            ui->depurador->append("Error al iniciar el servidor.");
        }
    }
}

void Qform1::handleNewConnection() {
    QTcpSocket *clientSocket = server->nextPendingConnection();

    QString clientIp = clientSocket->peerAddress().toString();

    // Eliminar el prefijo "::ffff:" si está presente (IPv6 a IPv4)
    if (clientIp.startsWith("::ffff:")) {
        clientIp = clientIp.mid(7); // Convertimos la IP a IPv4
    }

    // Verificar si la IP ya está en la lista de IPs conectadas
    if (!connectedIps.contains(clientIp)) {
        connectedIps.append(clientIp); // Añadir IP a la lista
        ui->depurador->append("Cliente conectado: " + clientIp);
    }

    // Manejo de errores de socket
    connect(clientSocket, &QTcpSocket::errorOccurred, this, [=](QAbstractSocket::SocketError socketError) {
        ui->depurador->append("Error en cliente " + clientIp + ": " + clientSocket->errorString());
    });

    // Manejo de datos leídos del cliente
    connect(clientSocket, &QTcpSocket::readyRead, this, &Qform1::handleClientMessage);
}










void Qform1::handleClientMessage() {
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket *>(sender());
    if (!clientSocket) return;
    QByteArray request = clientSocket->readAll();
    QStringList requestLines = QString(request).split("\r\n");
    if (requestLines.isEmpty()) {
        sendResponse(clientSocket, 400, "Bad Request", "Solicitud no válida.");
        return;
    }

    QStringList requestLine = requestLines[0].split(" ");
    if (requestLine.size() < 2) {
        sendResponse(clientSocket, 400, "Bad Request", "Solicitud no válida.");
        return;
    }

    QString method = requestLine[0];
    QString url = requestLine[1];

    // Manejo de archivos estáticos
    if(url == "/"){
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/inicio/inicio.html", "text/html");
    }
    else if(url == "/snake"){
         sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/snake/snake.html", "text/html");
    }else if(url == "/script_iniciar.js"){
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/inicio/script_iniciar.js", "application/javascript");
    }else if (url == "/race_four") {
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/race_four/index.html", "text/html");
    } else if (url == "/styles.css") {
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/race_four/styles.css", "text/css");
    }else if(url == "/styles_inicio.css"){
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/inicio/styles_inicio.css", "text/css");
    }else if (url == "/script.js") {
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/race_four/script.js", "application/javascript");
    }else if (url == "/script_snake.js") {
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/snake/script_snake.js", "application/javascript");
    } else if (url == "/style_snake.css") {
        sendStaticFile(clientSocket, "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/snake/style_snake.css", "text/css");
    }else if ((url == "/a1.png" || url == "/a2.png" || url == "/a3.png" || url == "/a4.png" || url == "/back_snake.png" || url == "/back_race.png")) {
        QString imagePath = "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www" + url;
        sendStaticFile(clientSocket, imagePath, "image/png");
    }
    // Endpoints POST Snake && autitos


    else if (url == "/send_score") {
        if (method != "POST") {
            sendResponse(clientSocket, 405, "Method Not Allowed", "Método no permitido.");
            return;
        }

        QByteArray requestBody = request.mid(request.indexOf("\r\n\r\n") + 4);
        QJsonDocument jsonDoc = QJsonDocument::fromJson(requestBody);

        if (!jsonDoc.isObject() || !jsonDoc.object().contains("score")) {
            sendResponse(clientSocket, 400, "Bad Request", "JSON inválido o faltan datos.");
            return;
        }

        int score = jsonDoc.object().value("score").toInt();
        QString clientIp = clientSocket->peerAddress().toString();

        // Almacenar el puntaje en el mapa global
        if (!globalScores.contains(clientIp)) {
            globalScores[clientIp] = QJsonArray();
        }
        globalScores[clientIp].append(score);

        sendResponse(clientSocket, 200, "OK", "Puntaje recibido.");
    }





    else if (url == "/change_direction") {
        if (method != "POST") {
            sendResponse(clientSocket, 405, "Method Not Allowed", "Método no permitido.");
            return;
        }

        QByteArray requestBody = request.mid(request.indexOf("\r\n\r\n") + 4);
        QJsonDocument jsonDoc = QJsonDocument::fromJson(requestBody);
        if (!jsonDoc.isObject()) {
            sendResponse(clientSocket, 400, "Bad Request", "JSON inválido.");
            return;
        }

        QString clientIp = clientSocket->peerAddress().toString();

        // Verificar si hay un estado existente para este cliente
        if (!globalSnakeStates.contains(clientIp)) {
            sendResponse(clientSocket, 404, "Not Found", "Estado del juego no encontrado.");
            return;
        }

        // Actualizar la dirección en el estado del cliente
        QJsonObject requestObj = jsonDoc.object();
        QJsonObject &snakeState = globalSnakeStates[clientIp];

        snakeState["speedX"] = requestObj.value("speedX").toInt();
        snakeState["speedY"] = requestObj.value("speedY").toInt();

        // Enviar una respuesta de éxito
        sendResponse(clientSocket, 200, "OK", "Dirección actualizada correctamente.");
    }

    else if (url == "/move_snake") {
        if (method != "POST") {
            sendResponse(clientSocket, 405, "Method Not Allowed", "Método no permitido.");
            return;
        }

        QByteArray requestBody = request.mid(request.indexOf("\r\n\r\n") + 4);
        QJsonDocument jsonDoc = QJsonDocument::fromJson(requestBody);
        if (!jsonDoc.isObject()) {
            sendResponse(clientSocket, 400, "Bad Request", "JSON inválido.");
            return;
        }

        QString clientIp = clientSocket->peerAddress().toString();

        // Obtener o inicializar el estado del juego
        QJsonObject snakeState;
        if (globalSnakeStates.contains(clientIp)) {
            snakeState = globalSnakeStates[clientIp];
        } else {
            snakeState = QJsonObject{
                {"snakeX", 5},
                {"snakeY", 5},
                {"speedX", 0},
                {"speedY", 0},
                {"snakeBody", QJsonArray()},
                {"foodX", QRandomGenerator::global()->bounded(17)},
                {"foodY", QRandomGenerator::global()->bounded(17)},
                {"score", 0},
                {"gameOver", false}
            };
            globalSnakeStates[clientIp] = snakeState;
        }

        // Actualizar el estado del juego basado en la solicitud
        QJsonObject requestObj = jsonDoc.object();
        int newSnakeX = requestObj.value("snakeX").toInt() + snakeState.value("speedX").toInt();
        int newSnakeY = requestObj.value("snakeY").toInt() + snakeState.value("speedY").toInt();
        QJsonArray snakeBody = snakeState.value("snakeBody").toArray();

        snakeBody.prepend(QJsonArray{newSnakeX, newSnakeY});  // Mover la cabeza

        if (newSnakeX == snakeState["foodX"].toInt() && newSnakeY == snakeState["foodY"].toInt()) {
            snakeState["score"] = snakeState["score"].toInt() + 100;
            snakeState["foodX"] = QRandomGenerator::global()->bounded(17);
            snakeState["foodY"] = QRandomGenerator::global()->bounded(17);
        } else {
            snakeBody.removeLast();
        }

        for (int i = 1; i < snakeBody.size(); ++i) {
            QJsonArray part = snakeBody[i].toArray();
            if (newSnakeX == part[0].toInt() && newSnakeY == part[1].toInt()) {
                snakeState["gameOver"] = true;
            }
        }

        if (newSnakeX < 0 || newSnakeX >= 17 || newSnakeY < 0 || newSnakeY >= 17) {
            snakeState["gameOver"] = true;
        }

        snakeState["snakeX"] = newSnakeX;
        snakeState["snakeY"] = newSnakeY;
        snakeState["snakeBody"] = snakeBody;

        // Guardar puntaje al finalizar el juego
        if (snakeState["gameOver"].toBool()) {
            int finalScore = snakeState["score"].toInt();
            if (!globalScores.contains(clientIp)) {
                globalScores[clientIp] = QJsonArray();
            }
            globalScores[clientIp].append(finalScore);
        }

        // Guardar el estado actualizado
        globalSnakeStates[clientIp] = snakeState;

        // Convertir `globalScores` a un QJsonArray para incluirlo en la respuesta
        QJsonArray scoresArray;
        for (auto it = globalScores.begin(); it != globalScores.end(); ++it) {
            QJsonObject scoreEntry;
            scoreEntry["ip"] = it.key();
            scoreEntry["scores"] = it.value();
            scoresArray.append(scoreEntry);
        }

        // Adjuntar los puntajes globales al JSON de respuesta
        QJsonObject responseObj = snakeState;
        responseObj["globalScores"] = scoresArray;

        // Enviar respuesta
        QJsonDocument responseDoc(responseObj);
        QByteArray responseBody = responseDoc.toJson();
        ui->depurador->clear();
        ui->depurador->append(responseBody);
        QString response = QString("HTTP/1.1 200 OK\r\n"
                                   "Content-Type: application/json\r\n"
                                   "Content-Length: %1\r\n"
                                   "Connection: close\r\n"
                                   "\r\n")
                               .arg(responseBody.size());

        clientSocket->write(response.toUtf8());
        clientSocket->write(responseBody);
        clientSocket->flush();
        clientSocket->disconnectFromHost();
    }






    else if (url == "/assign_car") {
        QString clientIp = clientSocket->peerAddress().toString();

        // Normalizar la IP si es necesario (manejo "::ffff:127.0.0.1")
        if (clientIp.startsWith("::ffff:")) {
            clientIp = clientIp.mid(7);
        }

        if (ipToCarMap.contains(clientIp)) {
            // Si ya tiene un auto asignado, devolver la carKey asignada
            QString assignedCar = ipToCarMap[clientIp];
            QJsonObject responseObj;
            responseObj["carKey"] = assignedCar;

            QJsonDocument responseDoc(responseObj);
            QByteArray responseBody = responseDoc.toJson();

            QString response = QString("HTTP/1.1 200 OK\r\n"
                                       "Content-Type: application/json\r\n"
                                       "Content-Length: %1\r\n"
                                       "Connection: keep-alive\r\n"  // Mantener la conexión abierta
                                       "\r\n")
                                   .arg(responseBody.size());
            clientSocket->write(response.toUtf8());
            clientSocket->write(responseBody);

            ui->depurador->append("Auto ya asignado: " + assignedCar + " para cliente: " + clientIp);
        } else {
            // Asignar un nuevo auto si no existe
            QStringList availableCars = {"a", "b", "c", "d"};
            bool carAssigned = false;

            for (const QString &car : availableCars) {
                if (!ipToCarMap.values().contains(car)) {
                    ipToCarMap[clientIp] = car;

                    QJsonObject responseObj;
                    responseObj["carKey"] = car;

                    QJsonDocument responseDoc(responseObj);
                    QByteArray responseBody = responseDoc.toJson();

                    QString response = QString("HTTP/1.1 200 OK\r\n"
                                               "Content-Type: application/json\r\n"
                                               "Content-Length: %1\r\n"
                                               "Connection: keep-alive\r\n"  // Mantener la conexión abierta
                                               "\r\n")
                                           .arg(responseBody.size());
                    clientSocket->write(response.toUtf8());
                    clientSocket->write(responseBody);

                    ui->depurador->append("Nuevo auto asignado: " + car + " para cliente: " + clientIp);
                    carAssigned = true;
                    break;
                }
            }

            if (!carAssigned) {
                QString response = QString("HTTP/1.1 503 Service Unavailable\r\n"
                                           "Content-Type: text/plain\r\n"
                                           "Content-Length: 25\r\n"
                                           "Connection: keep-alive\r\n"
                                           "\r\n"
                                           "No cars available now.");
                clientSocket->write(response.toUtf8());

                ui->depurador->append("No hay autos disponibles para cliente: " + clientIp);
            }
        }

        clientSocket->flush();
    }



    // Manejo del endpoint "/car_coord"
    else if (url == "/car_coord") {
        if (method != "POST") {
            sendResponse(clientSocket, 405, "Method Not Allowed", "Método no permitido.");
            return;
        }

        QByteArray requestBody = request.mid(request.indexOf("\r\n\r\n") + 4);
        QJsonDocument jsonDoc = QJsonDocument::fromJson(requestBody);
        if (!jsonDoc.isObject()) {
            sendResponse(clientSocket, 400, "Bad Request", "JSON inválido.");
            return;
        }

        QJsonObject requestObj = jsonDoc.object();
        QString carKey = requestObj.value("carKey").toString();
        double x = requestObj.value("x").toDouble();
        double y = requestObj.value("y").toDouble();
        double angulo = requestObj.value("angulo").toDouble();
        double speed = requestObj.value("speed").toDouble();

        // Actualizar la posición del auto
        x += qCos(angulo) * speed;
        y += qSin(angulo) * speed;

        // Guardar el estado actualizado del auto en el mapa global
        QJsonObject carState;
        carState["x"] = x;
        carState["y"] = y;
        carState["angulo"] = angulo;
        globalCarStates[carKey] = carState;

        // Crear una respuesta con todos los estados de los autos
        QJsonArray carStatesArray;
        for (const QString &key : globalCarStates.keys()) {
            QJsonObject state = globalCarStates[key];
            state["carKey"] = key; // Añadir la llave del auto al estado
            carStatesArray.append(state);
        }

        QJsonObject responseObj;
        responseObj["cars"] = carStatesArray;

        QJsonDocument responseDoc(responseObj);
        QByteArray responseBody = responseDoc.toJson();

        QString response = QString("HTTP/1.1 200 OK\r\n"
                                   "Content-Type: application/json\r\n"
                                   "Content-Length: %1\r\n"
                                   "Connection: close\r\n"
                                   "\r\n")
                               .arg(responseBody.size());

        QString debugText = "Estado global de los autos:\n";
        for (const QString &key : globalCarStates.keys()) {
            QJsonObject state = globalCarStates[key];
            debugText += QString("Car %1 -> X: %2, Y: %3, Ángulo: %4\n")
                             .arg(key)
                             .arg(state["x"].toDouble())
                             .arg(state["y"].toDouble())
                             .arg(state["angulo"].toDouble());

        }

        ui->depurador->setText(debugText); // Actualizar el depurador


        clientSocket->write(response.toUtf8());
        clientSocket->write(responseBody);
        clientSocket->flush();
        clientSocket->disconnectFromHost();
    }
    else if (url == "/get_scores")
    {
        if (method != "GET") {
            sendResponse(clientSocket, 405, "Method Not Allowed", "Método no permitido.");
            return;
        }
        QJsonObject responseJson;
        for (auto it = globalScores.begin(); it != globalScores.end(); ++it) {
            responseJson.insert(it.key(), it.value());
        }
        QJsonDocument jsonDoc(responseJson);
        QByteArray responseBody = jsonDoc.toJson();

        // Crear la respuesta HTTP
        QByteArray response;
        response.append("HTTP/1.1 200 OK\r\n");
        response.append("Content-Type: application/json\r\n");
        response.append("Content-Length: " + QByteArray::number(responseBody.size()) + "\r\n");
        response.append("\r\n");
        response.append(responseBody);

        clientSocket->write(response);    // Escribe los datos en el socket
        clientSocket->flush();
        clientSocket->disconnectFromHost(); // Cierra la conexión con el cliente
    }

    // Recurso no encontrado
    else {
        sendResponse(clientSocket, 404, "Not Found", "Recurso no encontrado.");
    }
}

void Qform1::sendStaticFile(QTcpSocket *socket, const QString &filePath, const QString &contentType) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        sendResponse(socket, 404, "Not Found", "Archivo no encontrado.");
        return;
    }

    QByteArray fileContent = file.readAll();
    file.close();

    QString response = QString("HTTP/1.1 200 OK\r\n"
                               "Content-Type: %1\r\n"
                               "Content-Length: %2\r\n"
                               "Connection: close\r\n"
                               "\r\n")
                           .arg(contentType)
                           .arg(fileContent.size());

    socket->write(response.toUtf8());
    socket->write(fileContent);
    socket->flush();
    socket->disconnectFromHost();
}





void Qform1::sendImage(QTcpSocket *socket, const QString &url) {
    // Determinar el nombre del archivo de la imagen
    QString imagePath = "/home/lucasnm/Works/qt_proyects/tp_server_one/tp_server_one/build/Desktop_Qt_6_8_0-Debug/www/" + url.mid(1);

    QFile imageFile(imagePath);
    if (!imageFile.open(QIODevice::ReadOnly)) {
        sendResponse(socket, 404, "Not Found", "Imagen no encontrada.");
        return;
    }

    QByteArray imageContent = imageFile.readAll();

    // Enviar la respuesta HTTP con el contenido de la imagen
    QString response = QString("HTTP/1.1 200 OK\r\n"
                               "Content-Type: image/png\r\n"
                               "Content-Length: %1\r\n"
                               "Connection: close\r\n"
                               "\r\n")
                           .arg(imageContent.size());

    socket->write(response.toUtf8());
    socket->write(imageContent);
    socket->flush();
    socket->disconnectFromHost();
}



void Qform1::sendResponse(QTcpSocket *socket, int statusCode, const QString &statusText,
                          const QString &message, const QMap<QString, QString>& headers)
{
    QString response = QString("HTTP/1.1 %1 %2\r\n"
                               "Content-Type: text/plain\r\n"
                               "Content-Length: %3\r\n"
                               "Connection: close\r\n")
                           .arg(statusCode)
                           .arg(statusText)
                           .arg(message.size());

    // Añadir los encabezados adicionales
    for (const QString& key : headers.keys()) {
        response.append(QString("%1: %2\r\n").arg(key).arg(headers[key]));
    }

    response.append("\r\n");
    response.append(message);

    socket->write(response.toUtf8());
    socket->flush();
    socket->disconnectFromHost();
}



