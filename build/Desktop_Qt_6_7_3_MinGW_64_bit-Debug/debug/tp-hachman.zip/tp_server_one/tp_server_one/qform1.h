#ifndef QFORM1_H
#define QFORM1_H

#include <QSet> // Para manejar autos disponibles
#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMap>
#include <QRandomGenerator>
#include <QFile>



extern QMap<QString, QString> ipToCarMap; // Relación IP -> Auto
extern QSet<QString> availableCars;       // Autos disponibles

QT_BEGIN_NAMESPACE
namespace Ui { class Qform1; }
QT_END_NAMESPACE

class Qform1 : public QMainWindow
{
    Q_OBJECT

public:
    Qform1(QWidget *parent = nullptr);
    ~Qform1();

private slots:

    void startServer();                          // Iniciar el servidor
    void handleNewConnection();                  // Manejar nuevas conexiones
    void handleClientMessage();                  // Manejar mensajes de los clientes

private:

    QStringList connectedIps;
    Ui::Qform1 *ui;
    QTcpServer *server;                         // Servidor TCP
    QList<QTcpSocket*> clientSockets;

     bool serverRunning = false;
    void sendResponse(QTcpSocket *socket, int statusCode, const QString &statusText,
                      const QString &message, const QMap<QString, QString>& headers = QMap<QString, QString>());

     void sendImage(QTcpSocket *socket, const QString &url);
    void sendStaticFile(QTcpSocket *socket, const QString &filePath, const QString &contentType);

};

#endif // QFORM1_H

